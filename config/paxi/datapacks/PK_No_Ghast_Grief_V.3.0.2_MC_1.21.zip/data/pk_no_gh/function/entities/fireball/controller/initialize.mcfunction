#> pk_no_gh:entities/fireball/controller/initialize

# Add tags
tag @s add pk.no_gh
tag @s add pk.no_gh.pacified_fireball
tag @s add pk.no_gh.pacified_fireball.controller

# Ride fireball
ride @s mount @e[type=fireball,tag=pk.current.fireball,limit=1,distance=..0.1]