#> pk_no_gh:entities/fireball/on_impact
#
# @context a fireball controller (marker) at @s

# Summon the bomb creeper
summon creeper ~ ~ ~ {ignited:true,Fuse:0s,Tags:["pk.no_cr.ignore","pk.current.creeper"],Silent:1b,ExplosionRadius:2,CustomName:'{"text":"Ghast"}'}

# Store and change mobGriefing
execute unless score $gamerule.mob_griefing.saved pk.value matches 1 store success score $gamerule.mob_griefing.previous_value pk.value run gamerule mobGriefing false
scoreboard players set $gamerule.mob_griefing.saved pk.value 1
schedule function pk_no_gh:helpers/restore_gamerule 2t replace

# Remove controller
kill @s