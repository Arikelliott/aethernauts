#> pk_no_gh:entities/fireball/check

# Mark projectile
tag @s add pk.no_gh.checked

# Stop execution if not shot by a ghast
execute on origin unless entity @s[type=ghast] run return fail

# Pacify projectile
function pk_no_gh:entities/fireball/pacify