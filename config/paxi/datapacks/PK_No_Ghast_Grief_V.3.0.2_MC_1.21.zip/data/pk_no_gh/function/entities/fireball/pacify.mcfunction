#> pk_no_gh:entities/fireball/pacify

# Add tags
tag @s add pk.no_gh
tag @s add pk.no_gh.pacified_fireball
tag @s add pk.no_gh.pacified_fireball.fireball

# Update data
data modify entity @s ExplosionPower set value 0b

# Summon controller
tag @s add pk.current.fireball
execute summon marker run function pk_no_gh:entities/fireball/controller/initialize
tag @s remove pk.current.fireball