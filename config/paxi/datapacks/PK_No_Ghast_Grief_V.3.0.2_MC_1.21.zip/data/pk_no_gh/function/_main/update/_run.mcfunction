#> pk_no_gh:_main/update/_run
#
# Update the current data pack if needed
#
# @writes score $pk.no_ghast_grief.version pk.value
#   The data pack's current version score
#
# @writes storage pk:common installed_datapacks[{id:"no_ghast_grief"}]
#       version: string
#           The data pack's current literal version

scoreboard players set $pk.no_ghast_grief.version pk.value 30002
data modify storage pk:common installed_datapacks[{id:"no_ghast_grief"}].version set value "3.0.2"