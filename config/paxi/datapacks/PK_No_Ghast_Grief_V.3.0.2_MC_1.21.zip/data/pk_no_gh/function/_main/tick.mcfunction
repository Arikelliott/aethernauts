#> pk_no_gh:_main/tick
#
# Main tick

# ―――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――― 
# Entities:
# ――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
# Fireball
#   Check origin
execute as @e[type=fireball,tag=!pk.no_gh.checked] at @s run function pk_no_gh:entities/fireball/check
# Pacified fireball
#   On impact
execute as @e[type=marker,tag=pk.no_gh.pacified_fireball.controller,predicate=!pk_no_gh:has_vehicle] at @s run function pk_no_gh:entities/fireball/on_impact