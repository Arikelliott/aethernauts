#> pk_no_gh:cmd/uninstall

function pk_no_gh:_main/uninstall/start